# Internship Web Development Projects

This repository contains four front-end web development projects created during my internship.

## Projects

### 1. Personal Portfolio Website
A simple portfolio site with sections for About Me, Projects, and Contact.

**Tech Used:** HTML, CSS

**Folder:** `/portfolio`

---

### 2. To-Do List App
A basic task manager that allows users to add and remove daily tasks.

**Tech Used:** HTML, CSS, JavaScript

**Folder:** `/todo`

---

### 3. Blog Platform (Frontend Only)
A frontend interface for posting and displaying blog content (no backend).

**Tech Used:** HTML, CSS, JavaScript

**Folder:** `/blog`

---

### 4. Weather App
An app to fetch current weather info for any city using the OpenWeatherMap API.

**Tech Used:** HTML, CSS, JavaScript (Fetch API)

**Folder:** `/weather`

**Note:** Replace `"your_api_key_here"` in `script.js` with your own [OpenWeatherMap API key](https://openweathermap.org/api).
